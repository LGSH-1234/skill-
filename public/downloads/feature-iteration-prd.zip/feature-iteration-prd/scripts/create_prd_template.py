#!/usr/bin/env python3
"""
PRD模板生成脚本
生成Word格式的PRD模板
"""

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE


def create_prd_template():
    doc = Document()

    # 设置标题
    title = doc.add_heading('[功能名称] PRD文档', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # 元信息表格
    meta_table = doc.add_table(rows=5, cols=2)
    meta_table.style = 'Table Grid'
    meta_data = [
        ('版本', 'v1.0'),
        ('日期', '[日期]'),
        ('作者', '[产品经理]'),
        ('状态', '[草稿/评审中/已完成]'),
    ]
    for i, (key, value) in enumerate(meta_data):
        meta_table.rows[i].cells[0].text = key
        meta_table.rows[i].cells[1].text = value

    doc.add_paragraph()

    # 1. 需求背景
    doc.add_heading('1. 需求背景', level=1)
    doc.add_paragraph('1.1 需求来源')
    doc.add_paragraph('[描述需求的来源，如：用户反馈、竞品分析、业务需求、数据分析等]')
    doc.add_paragraph('1.2 解决问题')
    doc.add_paragraph('[描述当前存在的问题，以及解决后预期达到的效果]')

    # 2. 用户场景分析
    doc.add_heading('2. 用户场景分析', level=1)
    doc.add_paragraph('2.1 目标用户')
    doc.add_paragraph('[描述目标用户群体的特征]')
    doc.add_paragraph('2.2 使用场景')
    doc.add_paragraph('[详细描述用户使用该功能的场景]')

    # 3. 竞品分析对比
    doc.add_heading('3. 竞品分析对比', level=1)
    doc.add_paragraph('3.1 竞品A')
    doc.add_paragraph('[竞品的功能描述和截图]')
    doc.add_paragraph('3.2 竞品B')
    doc.add_paragraph('[竞品的功能描述和截图]')
    doc.add_paragraph('3.3 本品分析')
    doc.add_paragraph('[本品当前的情况和需要改进的地方]')

    # 4. 功能需求描述
    doc.add_heading('4. 功能需求描述', level=1)
    doc.add_paragraph('4.1 功能点1：[功能名称]')
    doc.add_paragraph('功能描述')
    doc.add_paragraph('[做什么：详细描述这个功能要实现什么]')
    doc.add_paragraph('交互细节')
    doc.add_paragraph('[怎么做：用户如何操作]')
    doc.add_paragraph('界面布局')
    doc.add_paragraph('[怎么做：界面的布局、元素位置]')
    doc.add_paragraph('边界情况')
    doc.add_paragraph('[描述异常情况、边界条件的处理方式]')

    # 5. 页面流程图
    doc.add_heading('5. 页面流程图', level=1)
    doc.add_paragraph('[页面流程图，描述页面之间的跳转关系]')

    # 6. 业务流程图
    doc.add_heading('6. 业务流程图', level=1)
    doc.add_paragraph('[业务流程图，描述完整的业务流程]')

    # 7. 交互原型描述
    doc.add_heading('7. 交互原型描述', level=1)
    doc.add_paragraph('7.1 页面1：[页面名称]')
    doc.add_paragraph('页面布局')
    doc.add_paragraph('[页面整体布局描述]')
    doc.add_paragraph('操作流程')
    doc.add_paragraph('[用户在此页面的操作流程]')
    doc.add_paragraph('交互细节')
    doc.add_paragraph('[点击、长按、滑动、动画等细节]')

    # 8. 数据字典
    doc.add_heading('8. 数据字典/字段说明', level=1)
    doc.add_paragraph('8.1 [表名1]')
    # 添加字段表格
    field_table = doc.add_table(rows=2, cols=5)
    field_table.style = 'Table Grid'
    headers = ['字段名', '字段类型', '必填', '说明', '示例']
    for i, header in enumerate(headers):
        field_table.rows[0].cells[i].text = header
    field_table.rows[1].cells[0].text = 'field1'
    field_table.rows[1].cells[1].text = 'String'
    field_table.rows[1].cells[2].text = '是'
    field_table.rows[1].cells[3].text = '[描述]'
    field_table.rows[1].cells[4].text = '"示例"'

    # 9. 技术实现要求
    doc.add_heading('9. 技术实现要求', level=1)
    doc.add_paragraph('9.1 性能要求')
    doc.add_paragraph('[页面加载时间、接口响应时间等]')
    doc.add_paragraph('9.2 兼容性要求')
    doc.add_paragraph('[iOS、Android版本要求等]')
    doc.add_paragraph('9.3 安全要求')
    doc.add_paragraph('[用户数据加密、接口鉴权等]')

    # 10. 验收标准
    doc.add_heading('10. 验收标准', level=1)
    doc.add_paragraph('10.1 功能验收')
    doc.add_paragraph('[功能验收条件]')
    doc.add_paragraph('10.2 UI验收')
    doc.add_paragraph('[UI验收条件]')
    doc.add_paragraph('10.3 性能验收')
    doc.add_paragraph('[性能验收条件]')

    # 11. 优先级
    doc.add_heading('11. 优先级', level=1)
    priority_table = doc.add_table(rows=2, cols=3)
    priority_table.style = 'Table Grid'
    priority_table.rows[0].cells[0].text = '功能点'
    priority_table.rows[0].cells[1].text = '优先级'
    priority_table.rows[0].cells[2].text = '备注'
    priority_table.rows[1].cells[0].text = '[功能名称]'
    priority_table.rows[1].cells[1].text = 'P0'
    priority_table.rows[1].cells[2].text = '核心功能'

    # 12. 附录
    doc.add_heading('12. 附录', level=1)
    doc.add_paragraph('12.1 参考资料')
    doc.add_paragraph('[链接]')
    doc.add_paragraph('12.2 历史版本')
    doc.add_paragraph('[版本记录]')

    return doc


def main():
    doc = create_prd_template()
    output_path = 'prd_template.docx'
    doc.save(output_path)
    print(f"✅ PRD模板已生成: {output_path}")


if __name__ == "__main__":
    main()
