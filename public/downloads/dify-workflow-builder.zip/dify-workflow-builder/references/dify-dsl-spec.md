# Dify DSL 格式规范参考

## 目录

1. [顶层结构](#1-顶层结构)
2. [Workflow vs Chatflow](#2-workflow-vs-chatflow)
3. [Graph 结构：节点与边](#3-graph-结构节点与边)
4. [变量系统](#4-变量系统)
5. [所有节点类型](#5-所有节点类型)
6. [错误处理](#6-错误处理)
7. [完整示例](#7-完整示例)

---

## 1. 顶层结构

```yaml
app:
  description: '应用描述'
  icon: "\U0001F916"
  icon_background: '#FFEAD5'
  mode: workflow                     # "workflow" 或 "advanced-chat"
  name: 工作流名称
  use_icon_as_answer_icon: false
kind: app
version: '0.5.0'
workflow:
  conversation_variables: []
  environment_variables: []
  features:
    file_upload:
      enabled: false
      number_limits: 3
      allowed_file_types: []
      allowed_file_extensions: []
    opening_statement: ''
    retriever_resource:
      enabled: true
    sensitive_word_avoidance:
      enabled: false
    speech_to_text:
      enabled: false
    suggested_questions: []
    suggested_questions_after_answer:
      enabled: false
    text_to_speech:
      enabled: false
  graph:
    edges: [...]
    nodes: [...]
    viewport:
      x: 0
      y: 0
      zoom: 1
```

## 2. Workflow vs Chatflow

| 特性 | Workflow (`mode: workflow`) | Chatflow (`mode: advanced-chat`) |
|------|---------------------------|----------------------------------|
| 终止节点 | `end` | `answer`（可多个） |
| 系统变量 | `sys.user_id`, `sys.workflow_id`, `sys.workflow_run_id` | 额外有 `sys.query`, `sys.files`, `sys.conversation_id`, `sys.dialogue_count` |
| 会话变量 | 不可用 | 通过 `conversation_variables` 可用 |
| LLM 记忆 | 不可用 | 内置对话记忆开关 |
| 用途 | 单次运行自动化、批处理 | 多轮对话应用 |

## 3. Graph 结构：节点与边

### 3.1 节点结构

```yaml
nodes:
  - data:
      type: <node_type>
      title: "节点标题"
      desc: ""
      # ...节点类型特有配置
    id: '1720839738650'              # 唯一字符串ID（通常为时间戳）
    position:
      x: 80
      y: 282
    type: custom                     # 固定为 "custom"
```

布局建议：起始位置 `{x: 80, y: 282}`，节点水平间距 300-400 像素。

### 3.2 边结构

```yaml
edges:
  - id: 'source_id-source-target_id-target'
    source: 'source_node_id'
    sourceHandle: source             # "source", "success-branch", "fail-branch", 或 "{case_id}"
    target: 'target_node_id'
    targetHandle: target             # 固定为 "target"
    type: custom
    data:
      sourceType: start
      targetType: llm
      isInIteration: false
      isInLoop: false
```

**sourceHandle 取值：**
- `"source"` — 普通连接
- `"success-branch"` — 错误处理成功路径
- `"fail-branch"` — 错误处理失败路径
- `"{case_id}"` — if-else 或 question-classifier 的分支ID
- `"false"` — if-else 的 ELSE 分支

## 4. 变量系统

### 变量选择器格式

变量引用为数组：`[node_id, variable_name]`

Prompt 模板中的变量语法：`{{#node_id.variable_name#}}`

### 环境变量

```yaml
environment_variables:
  - id: 'ev_001'
    name: 'API_KEY'
    value: ''
    value_type: secret               # "secret" 或 "string"
    description: '外部API密钥'
```

### 会话变量（仅 advanced-chat）

```yaml
conversation_variables:
  - id: 'cv_001'
    name: 'chat_history'
    value_type: array[object]
    description: '存储对话上下文'
    value: []
```

## 5. 所有节点类型

### 5.1 Start（开始）

```yaml
- data:
    type: start
    title: 开始
    variables:
      - label: 输入文本
        max_length: 256
        options: []
        required: true
        type: text-input             # text-input, paragraph, select, number, file, file-list
        variable: input_text
  id: 'start_001'
  position: {x: 80, y: 282}
  type: custom
```

### 5.2 End（结束，workflow 模式）

```yaml
- data:
    type: end
    title: 结束
    outputs:
      - value_selector:
          - 'llm_001'
          - text
        variable: result
  id: 'end_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.3 Answer（回答，advanced-chat 模式）

```yaml
- data:
    type: answer
    title: 回答
    answer: '{{#llm_001.text#}}'
  id: 'answer_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.4 LLM

```yaml
- data:
    type: llm
    title: LLM
    model:
      provider: openai
      name: gpt-4o-mini
      mode: chat
      completion_params:
        temperature: 0.7
        top_p: 1.0
        max_tokens: 512
    prompt_template:
      - role: system
        text: '你是一个有帮助的助手。'
      - role: user
        text: '{{#start_001.input_text#}}'
    context:
      enabled: false
      variable_selector: []
    memory:
      enabled: false
      role_prefix:
        assistant: ''
        user: ''
      window:
        enabled: false
        size: 10
    vision:
      enabled: false
      configs:
        detail: high
  id: 'llm_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.5 Code（代码执行）

```yaml
- data:
    type: code
    title: 代码执行
    code_language: python3           # "python3" 或 "javascript"
    code: |
      def main(input_text: str) -> dict:
          result = input_text.upper()
          return {
              "output_text": result
          }
    variables:
      - variable: input_text
        value_selector:
          - 'llm_001'
          - text
    outputs:
      output_text:
        type: string                 # string, number, object, array[string], array[number], array[object]
  id: 'code_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.6 HTTP Request（HTTP 请求）

```yaml
- data:
    type: http-request
    title: HTTP 请求
    method: post
    url: 'https://api.example.com/data'
    headers: 'Content-Type: application/json'
    params: ''
    body:
      type: json                     # none, form-data, x-www-form-urlencoded, raw-text, json, binary
      data: |
        {
          "query": "{{#start_001.input_text#}}"
        }
    authorization:
      type: api-key
      config:
        type: bearer
        api_key: '{{#env.API_KEY#}}'
        header: ''
    timeout:
      connect: 10
      read: 60
      write: 20
    retry_config:
      max_retries: 3
      retry_interval: 100
  id: 'http_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.7 IF/ELSE（条件分支）

```yaml
- data:
    type: if-else
    title: 条件分支
    conditions:
      - id: 'condition_001'
        conditions:
          - comparison_operator: contains
            value: 'error'
            variable_selector:
              - 'llm_001'
              - text
            id: 'cond_item_001'
        logical_operator: and
  id: 'ifelse_001'
  position: {x: 680, y: 282}
  type: custom
```

边连接：
- IF 匹配：`sourceHandle: 'condition_001'`
- ELIF：`sourceHandle: 'condition_002'`
- ELSE：`sourceHandle: 'false'`

### 5.8 Question Classifier（问题分类器）

```yaml
- data:
    type: question-classifier
    title: 问题分类器
    model:
      provider: openai
      name: gpt-4o-mini
      mode: chat
      completion_params:
        temperature: 0.3
    query_variable_selector:
      - start_001
      - input_text
    classes:
      - id: 'class_001'
        name: '技术问题'
      - id: 'class_002'
        name: '一般咨询'
      - id: 'class_003'
        name: '投诉'
    instructions: '将用户问题分类到最合适的类别。'
    memory:
      enabled: false
  id: 'qc_001'
  position: {x: 380, y: 282}
  type: custom
```

边连接使用 class `id` 作为 `sourceHandle`。

### 5.9 Knowledge Retrieval（知识库检索）

```yaml
- data:
    type: knowledge-retrieval
    title: 知识库检索
    query_variable_selector:
      - start_001
      - input_text
    dataset_ids:
      - 'dataset_uuid_001'
    retrieval_mode: multiple
    multiple_retrieval_config:
      top_k: 3
      score_threshold: 0.5
      score_threshold_enabled: true
      reranking_mode: reranking_model
      reranking_model:
        provider: ''
        model: ''
    single_retrieval_config:
      model:
        provider: openai
        name: gpt-4o-mini
        mode: chat
        completion_params:
          temperature: 0.3
  id: 'kr_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.10 Variable Aggregator（变量聚合器）

```yaml
- data:
    type: variable-aggregator
    title: 变量聚合器
    variables:
      - - 'branch_a_node_id'
        - output
      - - 'branch_b_node_id'
        - output
    output_type: string
    advanced_settings:
      group_enabled: false
  id: 'va_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.11 Variable Assigner（变量赋值）

```yaml
- data:
    type: assigner
    title: 变量赋值
    assigned_variable_selector:
      - conversation
      - chat_history
    input:
      - variable_selector:
          - 'llm_001'
          - text
        value: ''
    operation: append                # overwrite, append, clear, set
  id: 'assign_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.12 Iteration（迭代）

```yaml
- data:
    type: iteration
    title: 迭代
    iterator_selector:
      - 'code_001'
      - list_output
    output_selector:
      - 'inner_llm_001'
      - text
    output_type: array[string]
    is_parallel: false
    parallel_nums: 10
    error_handle_mode: removed-output  # removed-output, continue-on-error, terminate
  id: 'iter_001'
  position: {x: 680, y: 282}
  type: custom
```

迭代内部节点使用 `{{#item#}}` 引用当前元素。

### 5.13 Loop（循环）

```yaml
- data:
    type: loop
    title: 循环
    loop_count: 100
    break_condition:
      conditions:
        - comparison_operator: '='
          value: 'done'
          variable_selector:
            - 'inner_node_id'
            - status
      logical_operator: and
    loop_variables:
      - id: 'lv_001'
        name: 'counter'
        value_type: number
        value: 0
  id: 'loop_001'
  position: {x: 680, y: 282}
  type: custom
```

### 5.14 Template Transform（模板转换）

```yaml
- data:
    type: template-transform
    title: 模板转换
    template: |
      摘要: {{ input_text }}
      时间: {{ timestamp }}
    variables:
      - variable: input_text
        value_selector:
          - 'llm_001'
          - text
      - variable: timestamp
        value_selector:
          - 'code_001'
          - ts
  id: 'template_001'
  position: {x: 680, y: 282}
  type: custom
```

使用 Jinja2 语法。输出固定为名为 `output` 的字符串变量。

### 5.15 Parameter Extractor（参数提取器）

```yaml
- data:
    type: parameter-extractor
    title: 参数提取器
    model:
      provider: openai
      name: gpt-4o-mini
      mode: chat
      completion_params:
        temperature: 0.2
    query_variable_selector:
      - start_001
      - input_text
    parameters:
      - name: city
        type: string
        description: '用户提到的城市名'
        required: true
      - name: date
        type: string
        description: 'YYYY-MM-DD 格式的日期'
        required: false
    instructions: '从用户查询中提取城市和日期。'
    memory:
      enabled: false
    reasoning_mode: prompt
  id: 'pe_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.16 Tool（工具节点）

```yaml
- data:
    type: tool
    title: Google 搜索
    provider_id: langgenius/google/google
    provider_name: google
    provider_type: builtin
    tool_name: google_search
    tool_label: Google Search
    tool_parameters:
      query:
        type: variable
        value:
          - 'start_001'
          - input_text
      result_type:
        type: constant
        value: json
    tool_configurations: {}
  id: 'tool_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.17 Document Extractor（文档提取器）

```yaml
- data:
    type: document-extractor
    title: 文档提取器
    variable_selector:
      - start_001
      - files
  id: 'doc_ext_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.18 List Operator（列表操作）

```yaml
- data:
    type: list-operator
    title: 列表操作
    variable_selector:
      - 'node_id'
      - list_output
    filter_by:
      enabled: true
      conditions:
        - key: status
          comparison_operator: '='
          value: active
    order_by:
      enabled: true
      key: score
      value: desc
    limit:
      enabled: true
      size: 10
  id: 'list_op_001'
  position: {x: 380, y: 282}
  type: custom
```

### 5.19 Agent 节点

```yaml
- data:
    type: agent
    title: Agent
    agent_strategy_provider: langgenius/agent_strategies/react
    agent_strategy_name: react
    model:
      provider: openai
      name: gpt-4o
      mode: chat
      completion_params:
        temperature: 0.5
    prompt_template:
      - role: system
        text: '你是一个有帮助的研究助手。'
    tools:
      - provider_id: langgenius/google/google
        provider_name: google
        provider_type: builtin
        tool_name: google_search
        tool_label: Google Search
        tool_parameters: {}
        tool_configurations: {}
    max_iterations: 5
    memory:
      enabled: true
  id: 'agent_001'
  position: {x: 380, y: 282}
  type: custom
```

## 6. 错误处理

三种策略：

```yaml
# 策略1: 无（默认）— 出错时停止工作流
error_strategy: none

# 策略2: 默认值 — 使用备用值
error_strategy: default-value
default_value:
  - key: text
    type: string
    value: '发生错误，请重试。'

# 策略3: 失败分支 — 路由到错误处理路径
error_strategy: fail-branch
```

重试配置：

```yaml
retry_config:
  max_retries: 3
  retry_interval: 100              # 毫秒
```

使用 `fail-branch` 时，节点产生两个边句柄：
- `sourceHandle: success-branch` — 正常路径
- `sourceHandle: fail-branch` — 错误路径

## 7. 完整示例

```yaml
app:
  description: '简单 LLM 工作流'
  icon: "\U0001F916"
  icon_background: '#FFEAD5'
  mode: workflow
  name: 简单LLM工作流
  use_icon_as_answer_icon: false
kind: app
version: '0.5.0'
workflow:
  conversation_variables: []
  environment_variables: []
  features:
    file_upload:
      enabled: false
    retriever_resource:
      enabled: false
  graph:
    edges:
      - data:
          sourceType: start
          targetType: llm
        id: start-llm
        source: 'start_001'
        sourceHandle: source
        target: 'llm_001'
        targetHandle: target
        type: custom
      - data:
          sourceType: llm
          targetType: end
        id: llm-end
        source: 'llm_001'
        sourceHandle: source
        target: 'end_001'
        targetHandle: target
        type: custom
    nodes:
      - data:
          type: start
          title: 开始
          variables:
            - label: 查询
              max_length: 256
              options: []
              required: true
              type: text-input
              variable: query
        id: 'start_001'
        position: {x: 80, y: 282}
        type: custom
      - data:
          type: llm
          title: LLM处理
          model:
            provider: openai
            name: gpt-4o-mini
            mode: chat
            completion_params:
              temperature: 0.7
              max_tokens: 512
          prompt_template:
            - role: system
              text: '你是一个有帮助的助手。'
            - role: user
              text: '{{#start_001.query#}}'
          context:
            enabled: false
            variable_selector: []
          memory:
            enabled: false
          vision:
            enabled: false
        id: 'llm_001'
        position: {x: 380, y: 282}
        type: custom
      - data:
          type: end
          title: 结束
          outputs:
            - value_selector:
                - 'llm_001'
                - text
              variable: result
        id: 'end_001'
        position: {x: 680, y: 282}
        type: custom
    viewport:
      x: 0
      y: 0
      zoom: 1
```

## 节点类型速查表

| 类型字符串 | 分类 | 说明 |
|-----------|------|------|
| `start` | 触发 | 入口，定义输入变量 |
| `end` | 终止 | 最终输出（workflow 模式） |
| `answer` | 终止 | 流式文本输出（advanced-chat 模式） |
| `llm` | AI处理 | LLM 调用 |
| `agent` | AI处理 | 自主推理+工具 |
| `question-classifier` | AI处理 | 问题分类路由 |
| `parameter-extractor` | AI处理 | 从文本提取结构化参数 |
| `knowledge-retrieval` | 数据 | 查询知识库 |
| `document-extractor` | 数据 | 从文件提取文本 |
| `code` | 逻辑 | Python3/JavaScript 执行 |
| `template-transform` | 逻辑 | Jinja2 文本模板 |
| `http-request` | 逻辑 | 外部API调用 |
| `tool` | 逻辑 | 内置/自定义工具调用 |
| `if-else` | 逻辑 | 条件分支 |
| `variable-aggregator` | 变量 | 合并分支输出 |
| `assigner` | 变量 | 写入会话变量 |
| `list-operator` | 数据 | 过滤/排序/限制数组 |
| `iteration` | 流程控制 | 遍历数组 |
| `loop` | 流程控制 | 条件循环 |

## 注意事项

1. **节点ID**通常为时间戳字符串（如 `'1720839738650'`），但可以是任意唯一字符串
2. **密钥在导出时会被清除**，Secret 类型的环境变量值为空
3. **DSL 版本**会影响导入兼容性，Agent 节点需要 v1.0+，Loop 节点需要 v1.2+
4. **模型字段**在 LLM 节点中使用 `name` 作为模型标识符
5. **所有节点的 `type` 字段**（外层）固定为 `"custom"`
